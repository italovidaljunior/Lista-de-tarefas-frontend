var input = document.getElementById('taskInput');
var taskBtn = document.getElementById('addTaskBtn');
var list = document.getElementById('taskList');

taskBtn.addEventListener('click', function() {
  if (input.value === '') {
    alert('Nada digitado')
  } else {
    var item = document.createElement("li");
    var deletar = document.createElement('button')
    deletar.textContent = 'X'
    item.textContent = input.value
    item.appendChild(deletar)
    list.appendChild(item);
    deletar.addEventListener('click' ,remover)
    function remover() {
      item.remove()
    }
  }
})

